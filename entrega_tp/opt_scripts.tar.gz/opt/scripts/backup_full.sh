#!/bin/bash
# ============================================
#  Script: backup_full.sh
#  Autor: Nahuel Matías Frutos
#  Descripción: Realizar backups comprimidos con nombre y fecha
# ============================================

# Mostrar ayuda
if [ "$1" == "-help" ] || [ $# -lt 2 ]; then
  echo "Uso: $0 <origen> <destino>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo
  echo "Opciones:"
  echo "  -help    Muestra esta ayuda"
  exit 0
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +"%Y%m%d")
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Validar existencia
if [ ! -d "$ORIGEN" ]; then
  echo "Error: el directorio de origen '$ORIGEN' no existe."
  exit 1
fi
if [ ! -d "$DESTINO" ]; then
  echo "Error: el directorio de destino '$DESTINO' no existe."
  exit 1
fi

# Crear backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Validar resultado
if [ $? -eq 0 ]; then
  echo "Backup creado correctamente: $ARCHIVO"
else
  echo "Error al crear el backup."
  exit 1
fi

